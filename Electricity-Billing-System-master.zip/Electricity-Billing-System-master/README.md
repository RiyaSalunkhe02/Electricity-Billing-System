# Electricity-Billing-System
A simple project made for implementing DBMS. Made using Java and mySQL. 
It allows a person to sign up as anemployee or as a customer who is looking for a new connection. A person can also login to their pre-existing account. 
Once you login as an employee, you can generate the bill for a customer, add another employee, add a customer, view all employees, view all customers, update customer details, delete a customer or view all services requested by the customer. 
To generate a bill, the employee requires the customer ID of the customer whose bill is to be generated. They also require the units consumed, payment mode and the total amount of the bill.
When a customer logs in, they can either view the bill generated or request a service. To request a service, the customer requires to enter the service type and the date on which the service is required.
This implements the concepts of JDBC, SQL CRUD Operations, Java GUI using Swings and other basic concepts of Java.
